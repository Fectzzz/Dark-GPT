// Suppression de la redirection automatique au chargement de la page pour éviter la boucle infinie
// window.addEventListener('load', () => {
//     window.location.href = 'menu.html'; // Redirige automatiquement vers le menu
// });

document.getElementById('get-started').addEventListener('click', () => {
    document.getElementById('menu').classList.add('hidden');
    document.getElementById('login').classList.remove('hidden');
});

document.querySelector('#login form').addEventListener('submit', (e) => {
    e.preventDefault(); // Empêche le rechargement de la page
    document.getElementById('login').classList.add('hidden');
    document.getElementById('chat').classList.remove('hidden');
});

// Ajout d'un événement pour rediriger tous les boutons "Commencer maintenant" vers la page de connexion
const startButtons = document.querySelectorAll('.btn-primary');
startButtons.forEach(button => {
    button.addEventListener('click', () => {
        window.location.href = 'login.html'; // Redirige vers la page de connexion
    });
});

// Correction du gestionnaire de changement de langue pour s'assurer qu'il fonctionne correctement
const languageSelector = document.querySelector('.language-selector');

languageSelector.addEventListener('change', (event) => {
    const selectedLanguage = event.target.value;

    // Exemple de gestion des langues (vous pouvez ajouter plus de traductions ici)
    const translations = {
        fr: {
            title: "DarkGPT - Menu",
            header: "DarkGPT",
            subtitle: "L'IA qui n'a aucune limite",
            button: "Commencer maintenant",
            footer: "Maximiser votre production"
        },
        en: {
            title: "DarkGPT - Menu",
            header: "DarkGPT",
            subtitle: "The AI with no limits",
            button: "Get Started",
            footer: "Maximize your productivity"
        },
        es: {
            title: "DarkGPT - Menú",
            header: "DarkGPT",
            subtitle: "La IA sin límites",
            button: "Comenzar ahora",
            footer: "Maximiza tu productividad"
        }
    };

    const translation = translations[selectedLanguage];

    if (translation) {
        // Mise à jour des textes sur la page
        document.title = translation.title;
        document.querySelector('header h1').textContent = translation.header;
        document.querySelector('.content-left h2').textContent = translation.subtitle;
        document.querySelectorAll('.btn-primary').forEach(button => {
            button.textContent = translation.button;
        });
        document.querySelector('footer h3').textContent = translation.footer;
    } else {
        console.error("Traduction non trouvée pour la langue :", selectedLanguage);
    }
});

// Ajout d'une animation de texte pour l'input non cliquable
const animatedInput = document.querySelector('#messageInput');
const phrases = [
    "Bonjour, comment puis-je vous aider ?",
    "Quelles sont vos questions aujourd'hui ?",
    "Je suis là pour répondre à toutes vos demandes."
];
let phraseIndex = 0;
let charIndex = 0;
let isDeleting = false;

function typeAnimation() {
    if (!animatedInput) return; // Vérifie que l'élément existe

    const currentPhrase = phrases[phraseIndex];
    if (isDeleting) {
        charIndex--;
    } else {
        charIndex++;
    }

    animatedInput.value = currentPhrase.substring(0, charIndex);

    if (!isDeleting && charIndex === currentPhrase.length) {
        isDeleting = true;
        setTimeout(typeAnimation, 2000); // Pause avant de supprimer
    } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        phraseIndex = (phraseIndex + 1) % phrases.length;
        setTimeout(typeAnimation, 500); // Pause avant de commencer une nouvelle phrase
    } else {
        setTimeout(typeAnimation, isDeleting ? 50 : 100);
    }
}

// Démarrer l'animation
if (animatedInput) {
    animatedInput.setAttribute('readonly', true); // Empêche l'utilisateur d'écrire dans l'input
    typeAnimation();
}

// Script to play the video only when it appears in the viewport
const video = document.getElementById('dynamicVideo');

function handleVideoPlayback() {
    const rect = video.getBoundingClientRect();
    const isVisible = rect.top >= 0 && rect.bottom <= window.innerHeight;

    if (isVisible) {
        video.play();
    } else {
        video.pause();
    }
}

window.addEventListener('scroll', handleVideoPlayback);
window.addEventListener('resize', handleVideoPlayback);