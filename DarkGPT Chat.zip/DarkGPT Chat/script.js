window.addEventListener('DOMContentLoaded', () => {
  const loader = document.getElementById('loader-screen');
  if (loader) {
    const delay = Math.random() * 3000 + 2000;
    setTimeout(() => {
      loader.style.display = 'none';
    }, delay);
  }
});

document.addEventListener('DOMContentLoaded', () => {
    const chatForm = document.getElementById('chat-form');
    const userInput = document.getElementById('user-input');
    const chatMessages = document.getElementById('chat-messages');
    const searchBtn = document.getElementById('search-btn');
    const intelligenceBtn = document.getElementById('intelligence-btn');
    const sidebar = document.getElementById('sidebar');
    const openSidebarBtn = document.getElementById('open-sidebar');
    const closeSidebarBtn = document.getElementById('close-sidebar');
    const conversationList = document.getElementById('conversation-list');
    const newConvBtn = document.getElementById('new-conv-btn');
    const deleteConvBtn = document.getElementById('delete-conv-btn');
    const renameConvBtn = document.getElementById('rename-conv-btn');
    const searchBtnMobile = document.getElementById('search-btn-mobile');
    const intelligenceBtnMobile = document.getElementById('intelligence-btn-mobile');

    function addMessage(text, sender) {
        const msgDiv = document.createElement('div');
        msgDiv.className = 'message ' + sender;
        msgDiv.textContent = text;
        chatMessages.appendChild(msgDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function fakeBotReply(userText) {
        setTimeout(() => {
            addMessageAndSave("Je suis DarkGPT. Voici une réponse simulée à : " + userText, 'bot');
        }, 700);
    }

    function updateSidebarChatOffset() {
        if (sidebar.classList.contains('open')) {
            document.querySelector('.chat-container').style.transform = window.innerWidth <= 900 ? 'translateX(60vw)' : 'translateX(270px)';
            document.querySelector('.chat-container').style.width = window.innerWidth <= 900 ? '40vw' : 'calc(100vw - 270px)';
        } else {
            document.querySelector('.chat-container').style.transform = '';
            document.querySelector('.chat-container').style.width = '';
        }
    }

    function toggleHeaderActions(show) {
        const headerActions = document.querySelector('.header-actions');
        if (headerActions) {
            headerActions.style.display = show ? 'flex' : 'none';
        }
    }

    openSidebarBtn.addEventListener('click', () => {
        sidebar.classList.add('open');
        updateSidebarChatOffset();
        toggleHeaderActions(false);
    });
    closeSidebarBtn.addEventListener('click', () => {
        sidebar.classList.remove('open');
        updateSidebarChatOffset();
        toggleHeaderActions(true);
    });
    window.addEventListener('resize', updateSidebarChatOffset);

    let conversations = JSON.parse(localStorage.getItem('darkgpt_conversations') || '[]');
    let currentConv = 0;
    if (conversations.length === 0) {
        conversations.push({ name: 'Conversation 1', messages: [] });
    }
    function saveConversations() {
        localStorage.setItem('darkgpt_conversations', JSON.stringify(conversations));
    }
    function renderConversations() {
        conversationList.innerHTML = '';
        conversations.forEach((conv, idx) => {
            const li = document.createElement('li');
            li.textContent = conv.name;
            if (idx === currentConv) li.classList.add('selected');
            li.addEventListener('click', () => {
                currentConv = idx;
                renderConversations();
                renderMessages();
            });
            conversationList.appendChild(li);
        });
    }
    function renderMessages() {
        chatMessages.innerHTML = '';
        conversations[currentConv].messages.forEach(msg => {
            addMessage(msg.text, msg.sender);
        });
    }
    newConvBtn.addEventListener('click', () => {
        const name = 'Conversation ' + (conversations.length + 1);
        conversations.push({ name, messages: [] });
        currentConv = conversations.length - 1;
        saveConversations();
        renderConversations();
        renderMessages();
    });

    const quickNewConvBtn = document.getElementById('quick-new-conv');
    if (quickNewConvBtn) {
        quickNewConvBtn.addEventListener('click', () => {
            const name = 'Conversation ' + (conversations.length + 1);
            conversations.push({ name, messages: [] });
            currentConv = conversations.length - 1;
            saveConversations();
            renderConversations();
            renderMessages();
        });
    }

    deleteConvBtn.addEventListener('click', () => {
        if (conversations.length <= 1) return;
        conversations.splice(currentConv, 1);
        currentConv = Math.max(0, currentConv - 1);
        saveConversations();
        renderConversations();
        renderMessages();
    });
    renameConvBtn.addEventListener('click', () => {
        const newName = prompt('Nouveau nom de la conversation :', conversations[currentConv].name);
        if (newName && newName.trim()) {
            conversations[currentConv].name = newName.trim();
            saveConversations();
            renderConversations();
        }
    });

    function addMessageAndSave(text, sender) {
        addMessage(text, sender);
        conversations[currentConv].messages.push({ text, sender });
        saveConversations();
    }
    let searchActive = false;
    searchBtn.addEventListener('click', () => {
        searchActive = !searchActive;
        searchBtn.classList.toggle('active', searchActive);
    });
    chatForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const text = userInput.value.trim();
        if (!text) return;
        addMessageAndSave(text, 'user');
        userInput.value = '';
        fakeBotReply(text);
        if (searchActive) {
            searchActive = false;
            searchBtn.classList.remove('active');
        }
    });

    intelligenceBtn.addEventListener('click', () => {
        intelligenceBtn.classList.toggle('active');
    });

    if (searchBtnMobile) {
        let searchActiveMobile = false;
        searchBtnMobile.addEventListener('click', () => {
            searchActiveMobile = !searchActiveMobile;
            searchBtnMobile.classList.toggle('active', searchActiveMobile);
        });
    }
    if (intelligenceBtnMobile) {
        intelligenceBtnMobile.addEventListener('click', () => {
            intelligenceBtnMobile.classList.toggle('active');
        });
    }

    renderConversations();
    renderMessages();
});